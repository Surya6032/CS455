#!C:/strawberry/perl/bin/perl
print "Content-type: text/html\r\n\r\n";
print "Hello, World.";

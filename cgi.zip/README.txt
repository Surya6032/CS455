1. first.pl is a very simple script that returns a Hello, World. page
2. read the instructions in name.cgi (paste form into index.html; process)
3. if time, place quiz.html in htdocs and quizParser.pl in cgi-bin
